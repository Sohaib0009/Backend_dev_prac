const asyncHandler = (reqHandeler) => {
  return (req, res, next) => {
    Promise.resolve(reqHandeler(req, res, next).catch((err) => next(err)));
  };
};
export { asyncHandler };
