import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { User } from "../models/users.models.js";
import {
  uploadOnCloudinary,
  deleteFromCloudinary,
} from "../utils/cloudinary.js";
import { ApiResponse } from "../utils/ApiResponse.js";

const registerUser = asyncHandler(async (req, res) => {
  const { fullname, email, username, password } = req.body;
  if (
    [fullname, email, username, password].some((field) => field?.trim() === "")
  ) {
    throw new ApiError(400, "Full name is required");
  }

  // check user Exist or not
  const existingUser = await User.findOne({
    $or: [{ username }, { email }],
  });
  if (existingUser) {
    throw new ApiError(409, "User exists");
  }

  console.warn("req.files", req.files);
  const avatarLocalPath = req.files?.avatar?.[0]?.path;
  const coverImageLocalPath = req.files?.coverImage?.[0]?.path;

  if (!avatarLocalPath) {
    throw new ApiError(400, "Avatar is required");
  }

  let avatar;
  try {
    avatar = await uploadOnCloudinary(avatarLocalPath);
    console.log("Avatar uploaded:", avatar);
  } catch (error) {
    console.log("Error uploading avatar:", error);
    throw new ApiError(500, "Error uploading avatar");
  }

  let coverImage;
  try {
    coverImage = await uploadOnCloudinary(coverImageLocalPath);
    console.log("Cover image uploaded:", coverImage);
  } catch (error) {
    console.log("Error uploading cover image:", error);
    throw new ApiError(500, "Error uploading cover image");
  }

  try {
    const user = await User.create({
      fullname,
      email,
      username: username.toLowerCase(),
      password,
      avatar: avatar.url,
      coverImage: coverImage?.url || "",
    });

    const createdUser = await User.findById(user._id).select(
      "-password -refreshToken"
    );

    if (!createdUser) {
      throw new ApiError(500, "User not created");
    }
    return res
      .status(201)
      .json(new ApiResponse(201, createdUser, "User created successfully"));
  } catch (error) { // images will be deleted if user creation fails..
    log.error("Error creating user:", error);
    if (avatar) {
      await deleteFromCloudinary(avatar.public_id);
    }
    if (coverImage) {
      await deleteFromCloudinary(coverImage.public_id);
    }
    throw new ApiError(500, "Error creating user // images were deleted");
  }
});

export { registerUser };

// import { asyncHandler } from "../utils/asyncHandler.js";
// import { ApiError } from "../utils/ApiError.js";
// import { User } from "../models/users.models.js";
// import { uploadOnCloudinary } from "../utils/cloudinary.js";
// import { ApiResponse } from "../utils/ApiResponse.js";

// // get user details from frontend and save it to database
// // validate user details
// // check if user already exists
// // check for image upload, avatar, etc
// // upload

// const registerUser = asyncHandler(async (req, res) => {
//   const { fullname, email, username, password } = req.body;
//   if (
//     [fullname, email, username, password].some((field) => field?.trim() === "")
//   ) {
//     throw new ApiError(400, "Full name is required");
//   }

//   const existingUser = await User.findOne({
//     $or: [{ username }, { email }],
//   });
//   if (existingUser) {
//     throw new ApiError(409, "user Exist... ");
//   }
//   console.warn("req.files", req.files);
//   const avatarLocalPath = req.files?.avatar?.[0]?.path;
//   const coverImageLocalPath = req.files?.coverImage?.[0]?.path;

//   if (!avatarLocalPath) {
//     throw new ApiError(400, "Avatar is required");
//   }

//   // const avatar = await uploadOnCloudinary(avatarLocalPath);
//   // let coverImage  = "";
//   // if (coverImageLocalPath) {
//   //   coverImage = await uploadOnCloudinary(coverImageLocalPath);
//   // }

//   let avatar;
//   try {
//     avatar = await uploadOnCloudinary(avatarLocalPath);
//     console.log("Avatar uploaded: ", avatar);
//   } catch (error) {
//     console.log("Error uploading avatar: ", error);
//     throw new ApiError(500, "Error uploading avatar");
//   }

//   let coverImage;
//   try {
//     coverImage = await uploadOnCloudinary(coverImageLocalPath);
//     console.log("coverImage uploaded: ", coverImage);
//   } catch (error) {
//     console.log("Error uploading CoverImage: ", error);
//     throw new ApiError(500, "Error uploading CoverImage");
//   }

//   const user = await User.create({
//     fullname,
//     email,
//     username: username.toLowerCase(),
//     password,
//     avatar: avatar.url,
//     coverImage: coverImage?.url || "",
//   });
//   const createdUser = user.findById(user._id).select("-password -refreshToken");

//   if (!createdUser) {
//     throw new ApiError(500, "User not created");
//   }

//   return res
//     .status(201)
//     .json(new ApiResponse(201, createdUser, "User created Successfully"));
// });
// export { registerUser };
